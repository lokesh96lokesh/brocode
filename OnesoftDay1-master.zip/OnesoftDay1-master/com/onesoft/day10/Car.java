package com.onesoft.day10;

public class Car {
	
	String brand;
	int price;
	Engine engine;

}

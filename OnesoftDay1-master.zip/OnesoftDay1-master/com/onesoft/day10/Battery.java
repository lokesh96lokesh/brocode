package com.onesoft.day10;

public class Battery {
	
	int capacity;
	int battertyPrice;
	
}

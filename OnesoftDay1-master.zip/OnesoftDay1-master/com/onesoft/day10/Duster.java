package com.onesoft.day10;

public class Duster {
	
	String brand;
	int price;
	String color;
	boolean isWood;
	
	public Duster(String brand,int price,String color,boolean isWood)
	{
		this.brand=brand;
		this.price=price;
		this.color=color;
		this.isWood=isWood;
	}

}

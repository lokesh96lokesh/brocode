package com.onesoft.day10;

public class Mobile {
	
	String Name;
	int price;
	Battery battery;

}

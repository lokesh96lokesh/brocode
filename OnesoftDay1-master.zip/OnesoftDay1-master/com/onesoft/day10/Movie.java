package com.onesoft.day10;

public class Movie {
	String name;
	private int ticketPrice;
	private String typeOfMovie;
	
	public int getTicketPrice() {
		return ticketPrice;
	}
	public void setTicketPrice(int ticketPrice) {
		this.ticketPrice = ticketPrice;
	}
	public String getTypeOfMovie() {
		return typeOfMovie;
	}
	public void setTypeOfMovie(String typeOfMovie) {
		this.typeOfMovie = typeOfMovie;
	}
	

}

package com.onesoft.day10;

public class Rubber {
	
	 String brand;
	 int price;
	 String color;
	 public Rubber(String brand,int price,String color)
	 {
		 this.brand=brand;
		 this.price=price;
		 this.color=color;
	 }

	 
}

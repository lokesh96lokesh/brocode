package com.onesoft.day10;

public class UseRubber {
	public static void main(String[] args) {
		Rubber r=new Rubber("Apsara",5,"WHITE");
		System.out.println(r.brand+","+r.price+" "+r.color);
	}

}

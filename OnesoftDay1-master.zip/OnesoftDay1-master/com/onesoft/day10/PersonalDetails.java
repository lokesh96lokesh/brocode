package com.onesoft.day10;

public class PersonalDetails {
	
	String FatherName;
	long mobileNo;
	String address;
	

}

package com.onesoft.day10;

public class Employee {
	
	String employeeName;
	int salary;
	String designation;
	PersonalDetails personalDetails;

}

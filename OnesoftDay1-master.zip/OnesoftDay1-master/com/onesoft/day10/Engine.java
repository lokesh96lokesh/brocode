package com.onesoft.day10;

public class Engine {
	
	int enginecc;
	String engineBrand;
	int noOfPiston;
	
}

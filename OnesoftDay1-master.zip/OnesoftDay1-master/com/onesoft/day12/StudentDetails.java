package com.onesoft.day12;

public interface StudentDetails {
	
	void studentName(String name);
	void studentSection(int section);

}

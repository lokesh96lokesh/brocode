package com.onesoft.day12;

public interface Students {
	
	void marks(int marks);
	void percentage(int percentage);

}

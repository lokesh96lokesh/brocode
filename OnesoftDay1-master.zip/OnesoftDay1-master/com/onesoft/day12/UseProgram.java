package com.onesoft.day12;

public class UseProgram {
	
	public static void main(String[] args) {
		
		Program p=new Program();
		System.out.println(p.calculatePerDaySalary(500, 8));
		System.out.println(p.getWork("kmjnbygtf"));
		//System.out.println(p.name="Suresh");
		//System.out.println(p.id=5487);
		
	}

}

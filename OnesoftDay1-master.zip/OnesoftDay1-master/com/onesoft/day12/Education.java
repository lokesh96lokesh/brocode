package com.onesoft.day12;

public interface Education {
	
	void findstaffName(String name);

}

package com.onesoft.day12;

public interface Car {
	
	public String brand(String brand);
	public boolean isElectric(boolean isElectric);
	public int price(int price);
	public String color(String color);


}

package com.onesoft.day12;

public class UseClass {
	public static void main(String[] args) {
		
		OnlineCourse oc=new OnlineCourse();
		oc.courseFees("Java");
		oc.courseHours(360);
		oc.courseLink("www.OneSofts.in");
		oc.CourseTrainerName("Nishanthi");
	}

}

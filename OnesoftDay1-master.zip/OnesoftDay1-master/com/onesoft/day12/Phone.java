package com.onesoft.day12;

public interface Phone {
	
	void voiceCall();
	void videoCall();
	void connectivity();
	void cameraFunction(String tapping);

}

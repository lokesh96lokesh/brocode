package com.onesoft.day12;

public interface Course {
	
	void courseLink(String url);
	void CourseTrainerName(String name);
	void courseFees(String courseName);
	void courseHours(int hours);
	
}

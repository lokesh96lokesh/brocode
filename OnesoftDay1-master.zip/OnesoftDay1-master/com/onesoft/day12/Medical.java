package com.onesoft.day12;

public class Medical extends College {
	
	public void collegeName() {
		
		System.out.println("SM");

	}
	

	}

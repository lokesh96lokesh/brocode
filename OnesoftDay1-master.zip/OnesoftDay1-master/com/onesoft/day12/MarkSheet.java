package com.onesoft.day12;

public class MarkSheet implements StudentDetails,Students {

	
	public void marks(int marks) {
		
		System.out.println(marks);
			
	}
	public void percentage(int percentage) {
		System.out.println(percentage);
		
	}

	public void studentName(String name) {
		System.out.println(name);
		
	}

	public void studentSection(int section) {
		
		System.out.println(section);
		
	}
	
	

}

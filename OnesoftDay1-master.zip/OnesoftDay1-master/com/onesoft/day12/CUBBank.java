package com.onesoft.day12;

public class CUBBank extends Bank {

	long accNum(long num) {
		return num;
	}

	int pinNum(int pin) {
		return pin;
	}

}

package com.onesoft.day12;

public class UseMarkSheet {
	public static void main(String[] args) {
		
	MarkSheet ms=new MarkSheet();
	ms.marks(380);
	ms.percentage(70);
	ms.studentName("Suresh");
	ms.studentSection(10);
	
	
	}
	

}

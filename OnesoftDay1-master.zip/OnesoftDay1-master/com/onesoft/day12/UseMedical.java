package com.onesoft.day12;

public class UseMedical {
	
	public static void main(String[] args) {
	
		Medical m=new Medical();
		m.collegeName();
		m.findstaffName("Nisha");
		System.out.println(m.findIdNo(5456));
		
	}

}

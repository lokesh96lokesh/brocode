package com.onesoft.day5;

public class ToFindUpperCase {
	public static void main(String[] args) {
		
		String s="Suresh";
		String uc = s.toUpperCase();
		if(s.equals(uc))
		{
			System.out.println("Fully UpperCase");
		}
		else 
		{
			System.out.println("Not Fully UpperCase");
		}
		
		
	}

}

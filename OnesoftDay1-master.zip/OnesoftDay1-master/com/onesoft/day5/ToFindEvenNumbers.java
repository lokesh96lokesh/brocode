package com.onesoft.day5;

public class ToFindEvenNumbers {
	public static void main(String[] args) {
		
		int num=5;
		if(num%2==0)
		{
			System.out.println("Even Number");
		}
		else
		{
			System.out.println("Not a Even Number");
		}
	}

}

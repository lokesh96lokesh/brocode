package com.onesoft.day5;

public class ToFindRetirement {
	public static void main(String[] args) {
		
		int age = 50;
		if(age>=60)
		{
			System.out.println("Eligle for Retirement");
		}
		else
		{
			System.out.println("Not Eligile For Retirement");
		}
	}

}

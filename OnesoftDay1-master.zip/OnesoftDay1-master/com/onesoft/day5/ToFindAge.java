package com.onesoft.day5;

public class ToFindAge {
	public static void main(String[] args) {
		
		int age=10;
		if(age>=18)
		{
			System.out.println("Eligible For Vote");
		}
		else
		{
			System.out.println("Not Eligile For Vote");
		}
	}

}

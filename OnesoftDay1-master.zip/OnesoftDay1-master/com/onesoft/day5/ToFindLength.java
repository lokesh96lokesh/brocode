package com.onesoft.day5;

public class ToFindLength {
	public static void main(String[] args) {
		
		String name = "Suresh";
		int length = name.length();
		if(length>=5)
		{
			System.out.println("Length of the Name is More than five");
		}
		else
		{
			System.out.println("Length of the Name is less that five");
		}
	}

}

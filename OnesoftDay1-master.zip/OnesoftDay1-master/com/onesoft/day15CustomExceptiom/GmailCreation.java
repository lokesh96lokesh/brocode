package com.onesoft.day15CustomExceptiom;

public class GmailCreation extends Exception{
	
	public GmailCreation(String msg) 
	{
		super(msg);
	}
	
	

}

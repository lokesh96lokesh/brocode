package com.onesoft.day15CustomExceptiom;

public class AgeException extends Exception {

	public AgeException(String msg)
	{
		super(msg);
	}
}

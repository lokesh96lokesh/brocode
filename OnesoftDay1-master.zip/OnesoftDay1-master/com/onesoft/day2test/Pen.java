package com.onesoft.day2test;

public class Pen {

	String brand;
	int price;
	boolean isBlueColor;
	float tipWidth;
	float averagePrice;

}

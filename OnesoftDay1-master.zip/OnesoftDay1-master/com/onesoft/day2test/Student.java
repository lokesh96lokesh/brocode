package com.onesoft.day2test;

public class Student {

	String name;
	int id;
	int age;
	String std;
	float attendancePercentage;
	int numberOfDaysPresent;

}

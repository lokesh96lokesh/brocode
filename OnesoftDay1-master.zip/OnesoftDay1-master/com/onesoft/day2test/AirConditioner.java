package com.onesoft.day2test;

public class AirConditioner {
	
	String brand;
	int price;
	int noOfWings;
	boolean isQuality;


}

package com.onesoft.day2test;

public class Marker {

	int price;
	String color;
	float weight;
	boolean isQuality;

}

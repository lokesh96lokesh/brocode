package com.onesoft.day2test;

public class StudentDetails {
	
	String studentName;
	int studentAge;
	long studentMobileNo;
	char classSection;
	int marksPercentage;

}

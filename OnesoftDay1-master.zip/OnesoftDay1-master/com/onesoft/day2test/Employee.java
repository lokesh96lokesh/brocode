package com.onesoft.day2test;

public class Employee {
	
	int employeeId;
	String employeeName;
	String dateOfBirth;
	long mobileNo;
	

}

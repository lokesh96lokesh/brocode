package com.onesoft.day2test;

public class AccountHolder {

	String name;
	int age;
	String gender;
	long accountNumber;
	int monthlyIncome;
	float savingsPercentage;

}

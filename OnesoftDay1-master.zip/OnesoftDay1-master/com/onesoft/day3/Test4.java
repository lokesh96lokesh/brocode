package com.onesoft.day3;

public class Test4 {
	
	public static void main(String[] args) {
		
		int[] a= {10,20,30};
		System.out.println(a[0]);
		System.out.println(a[1]);
		System.out.println(a[2]);
		
	}

}

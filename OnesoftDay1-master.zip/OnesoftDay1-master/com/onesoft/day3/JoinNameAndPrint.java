package com.onesoft.day3;

public class JoinNameAndPrint {

	public static void main(String[] args) {

		String s = "Suresh";
		System.out.println(s.concat("Devadass"));
	}

}

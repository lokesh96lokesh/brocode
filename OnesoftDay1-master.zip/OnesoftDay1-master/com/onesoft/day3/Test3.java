package com.onesoft.day3;

public class Test3 {
	public static void main(String[] args) {
		
		String s="DOG";
		char[]a=s.toCharArray();
		System.out.println(a[0]);
		System.out.println(a[1]);
		System.out.println(a[2]);
	}

}

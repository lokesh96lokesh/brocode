package com.onesoft.day3;

public class ToCheck {

	public static void main(String[] args) {

		String s = "Suresh";
		System.out.println(s.contains("rs"));
		System.out.println(s.startsWith("x"));
		System.out.println(s.endsWith("h"));
		System.out.println(s.equals("suresh"));
		System.out.println(s.equalsIgnoreCase("Suresh"));
		
	}

}

package com.onesoft.day3;

public class PrintNameUpperCase {
	public static void main(String[] args) {

		String s = "suresh";
		System.out.println(s.toUpperCase());

	}

}

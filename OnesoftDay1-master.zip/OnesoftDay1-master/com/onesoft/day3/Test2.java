package com.onesoft.day3;

public class Test2 {
	
	public static void main(String[] args)
	{
		String s="Suresh";
		System.out.println(s.charAt(2));
	    System.out.println(s.charAt(s.length()-1));
	    
	    System.out.println(s.indexOf('r'));
	    System.out.println(s.indexOf('h'));
	    
	    System.out.println(s.substring(1,3));
		
	}

}

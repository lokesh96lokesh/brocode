package com.onesoft.day3;

public class FindTheLength {
	
	public static void main(String[] args) {
		
		String s="suresh";
		System.out.println(s.length());
		
	}

}

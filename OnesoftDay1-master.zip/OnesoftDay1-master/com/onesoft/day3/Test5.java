package com.onesoft.day3;

public class Test5 {
	
	public static void main(String[] args) {
		
		String s="HelloWorld";
		String[] sp = s.split("o");
		System.out.println(sp[0]);
		System.out.println(sp[1]);
		System.out.println(sp[2]);
		System.out.println(sp.length);
	}

}

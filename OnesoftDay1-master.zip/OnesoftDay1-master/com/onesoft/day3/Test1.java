package com.onesoft.day3;

public class Test1 {

	public static void main(String[] args)
	{
		String firstName="Ram";
		String lastName="Kumar";
		System.out.println(firstName.concat(lastName).toUpperCase()+" Length is : "+firstName.concat(lastName).length());
	}
}

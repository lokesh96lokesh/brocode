package com.onesoft.day3;

public class PrintNameLowerCase {
	
	public static void main(String[] args)
	{
		String s="SURESH";
		System.out.println(s.toUpperCase());
		
	}

}

package com.onesoft.day16Java8;

public class UseHello {
	
public static void main(String[] args) {
	
	Hello.num=10;
	Hello h1=new Hello();
	Hello h2=new Hello();
	Hello h3=new Hello();
	
	
}	

}

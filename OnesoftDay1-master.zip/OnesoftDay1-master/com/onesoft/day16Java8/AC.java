package com.onesoft.day16Java8;

public class AC implements Electronics {

	@Override
	public void print() {
		System.out.println("Electronics");
	}

}

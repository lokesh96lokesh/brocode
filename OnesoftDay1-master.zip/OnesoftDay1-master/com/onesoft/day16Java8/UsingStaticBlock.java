package com.onesoft.day16Java8;

public class UsingStaticBlock {
	public static void main(String[] args) {
		System.out.println("Hello");
	}
	static
	{
		System.out.println("Welcome");
	}

}

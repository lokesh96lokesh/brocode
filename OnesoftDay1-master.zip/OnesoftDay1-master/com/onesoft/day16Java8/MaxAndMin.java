package com.onesoft.day16Java8;

public interface MaxAndMin {
	public int find(int a[]);
	

}

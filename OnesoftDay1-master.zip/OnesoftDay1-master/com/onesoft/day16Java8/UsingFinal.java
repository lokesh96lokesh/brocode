package com.onesoft.day16Java8;

public class UsingFinal {

	static final int num = 10;

	public static void main(String[] args) {

		//UsingFinal f = new UsingFinal();
		// f.num=100;
		System.out.println(num);
	}

}

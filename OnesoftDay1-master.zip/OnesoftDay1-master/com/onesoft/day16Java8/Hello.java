package com.onesoft.day16Java8;

public class Hello {
	
	static int num=0;
	public Hello()
	{
		num++;
		System.out.println(num);
	}


}

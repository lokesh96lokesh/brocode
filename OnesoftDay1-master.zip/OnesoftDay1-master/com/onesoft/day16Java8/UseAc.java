package com.onesoft.day16Java8;

public class UseAc {
	public static void main(String[] args) {
		
		Electronics.onOff(false);
		AC ac=new AC();
		ac.print();
	}

}

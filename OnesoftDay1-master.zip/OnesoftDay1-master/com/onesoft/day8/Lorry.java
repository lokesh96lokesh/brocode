package com.onesoft.day8;

public class Lorry {
	String brand;
	int price;
	int noOfWheel;
	boolean isNationalTBoard;

}

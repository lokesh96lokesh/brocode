package com.onesoft.day8;

public class Shirt {
	
	String brand;
	int price;
	String color;
	boolean isChecked;
	

}

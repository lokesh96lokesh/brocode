
package com.onesoft.day8;

public class Bike {

	String bikeName;
	int registerNo;
	boolean isPetrol;
	String colour;
}

package com.onesoft.day8;

public class WaterBottle {
	String material;
	int price;
	String colour;
	int capacity;

}

package com.onesoft.day8;

public class Pen {
	
	int price;
	String brand;
	boolean isColor;
	String isInkType;

}

package com.onesoft.day8;

public class Student {
	
	String name;
	int rollNo;
	char initial;
	long adhaarNo;
	int weight;


}

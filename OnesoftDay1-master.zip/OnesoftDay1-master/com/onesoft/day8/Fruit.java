package com.onesoft.day8;

public class Fruit {

	String name;
	int price;
	boolean isHybrid;

}

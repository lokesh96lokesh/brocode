package com.onesoft.day6;

public class ReversePrinting4 {
	public static void main(String[] args) {
		
		for(int i=9;i>=1;i=i-2)
		{
			System.out.println("Odd Number : "+i);
		}
	}

}

package com.onesoft.day6;

public class ForwardPrinting6 {
	public static void main(String[] args) {
		
		String s="Suresh";
		for(int i=1;i<=100;i++) {
			System.out.println(i +"."+ s);
		}
		
	}

}

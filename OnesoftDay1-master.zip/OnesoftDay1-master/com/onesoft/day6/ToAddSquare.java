package com.onesoft.day6;

public class ToAddSquare {
	public static void main(String[] args) {
		
		int temp=0;
		for(int i=0;i<=5;i++)
		{
			temp=temp+(i*i);
		}
		System.out.println(temp);
	}

}

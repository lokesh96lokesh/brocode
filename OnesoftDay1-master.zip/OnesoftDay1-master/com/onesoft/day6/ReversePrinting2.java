package com.onesoft.day6;

public class ReversePrinting2 {
	
	public static void main(String[] args) {
		
		for(int i=21;i>=10;i--)
		{
			System.out.println(i);
		}
	}

}

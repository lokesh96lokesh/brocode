package com.onesoft.day6;

public class ToCheckNeutralNumber {
	public static void main(String[] args) {
		
		for(int i=-25;i<=25;i++)
		{
			if(i==0)
			{
				System.out.println("Neutral Number is : "+i);
			}
		}
	}

}

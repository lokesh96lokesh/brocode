package com.onesoft.day6;

public class ToMultiply {
	
	public static void main(String[] args) {
		
		int temp=1;
		
		for(int i=1;i<=5;i++)
		{
			temp=temp*i;
		}
		System.out.println(temp);
	}

}

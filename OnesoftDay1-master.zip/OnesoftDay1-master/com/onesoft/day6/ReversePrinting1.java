package com.onesoft.day6;

public class ReversePrinting1 {
	
	public static void main(String[] args) {
		
		for(int i=5;i>=0;i--)
		{
			System.out.println(i);
		}
	}

}

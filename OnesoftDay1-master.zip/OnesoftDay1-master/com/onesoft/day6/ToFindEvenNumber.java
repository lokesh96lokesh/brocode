package com.onesoft.day6;

public class ToFindEvenNumber {
	public static void main(String[] args) {
		
		for(int i=20;i>=10;i--)
		{
			if(i%2==0)
			{
				System.out.println(i + " is a Even Number");
			}
		}
	}

}

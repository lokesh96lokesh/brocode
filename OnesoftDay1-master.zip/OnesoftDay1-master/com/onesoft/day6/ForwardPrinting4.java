package com.onesoft.day6;

public class ForwardPrinting4 {
	public static void main(String[] args) {
		
		for(int i=5;i<=12;i++)
		{
			System.out.println(i+" Square is : "+(i*i));
		}
	}

}

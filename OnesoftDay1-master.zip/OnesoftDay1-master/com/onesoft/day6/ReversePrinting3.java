package com.onesoft.day6;

public class ReversePrinting3 {
	
	public static void main(String[] args) {
		
		for(int i=1001;i>=501;i--)
		{
			System.out.println(i);
		}
	}

}

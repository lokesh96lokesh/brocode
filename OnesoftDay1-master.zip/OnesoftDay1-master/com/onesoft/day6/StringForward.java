package com.onesoft.day6;

public class StringForward {
	
	public static void main(String[] args) {
		
		String s="Suresh";
		for(int i=0;i<s.length();i++) {
		System.out.println(s.charAt(i));
		}
	}

}

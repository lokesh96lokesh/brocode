package com.onesoft.day6;

public class ToAdd {
	public static void main(String[] args) {

		int temp = 0;

		for (int i = 1; i <= 5; i++) {

			temp = temp + i;

		}
		System.out.println(temp);
	}

}

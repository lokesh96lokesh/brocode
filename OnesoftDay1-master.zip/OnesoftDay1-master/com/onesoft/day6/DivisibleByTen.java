package com.onesoft.day6;

public class DivisibleByTen {
	public static void main(String[] args) {
		
		for(int i=1;i<=1000;i++) {
			
			if(i%10==0)
			{
				System.out.println(i + " is divisible by 10");
			}
		}
	}

}

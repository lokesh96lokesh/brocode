package com.onesoft.day6;

public class ForwardPrinting5 {
	public static void main(String[] args) {
		
		for(int i=12;i>=5;i--)
		{
			System.out.println(i+" Cube is : "+(i*i*i));
	}
		
	}

}

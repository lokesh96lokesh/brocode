package com.onesoft.day6;

public class PrintOddIndex {
	
	public static void main(String[] args) {
		
		for(int i=1;i<=10;i=i+2)
		{
			System.out.println("Odd Number : "+i);
		}
	}

}

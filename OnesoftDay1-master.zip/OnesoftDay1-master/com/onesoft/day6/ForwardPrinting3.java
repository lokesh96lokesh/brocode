package com.onesoft.day6;

public class ForwardPrinting3 {
	
	public static void main(String[] args) {
		
		for(int i=1500;i<=2000;i++)
		{
			System.out.println(i);
		}
	}

}

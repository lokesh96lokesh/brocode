package com.onesoft.day6;

public class ReversePrinting5 {
	public static void main(String[] args) {
		
		for(int i=10;i>=0;i=i-2)
		{
			System.out.println("Even Number : "+i);
		}
	}

}

package com.onesoft.day6;

public class ToFindFibonacci {
	public static void main(String[] args) {	
		
		for(int i=1;i<=10;i++) {
			
			
			
		}
	}

}

package com.onesoft.day6;

public class ToFindCount {
	public static void main(String[] args) {
		
		int count=0;
		
		for(int i=0;i<=5;i++) {
			
			count++;
		}
		System.out.println(count);
	}

}

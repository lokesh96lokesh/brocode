package com.onesoft.day6;

public class StringReverse {
	
	public static void main(String[] args) {
		
		String s="Suresh";
		
		for(int i=s.length()-1;i>=0;i--)
		{
			System.out.println(s.charAt(i));
		}
	}

}

package com.onesoft.day4;

public class Addition {
	
	public static void main(String[] args) {
		
		String s=args[0];
		String s1=args[1];
		int num1 = Integer.parseInt(s);
		int num2 = Integer.parseInt(s1);
		System.out.println(num1);
		System.out.println(num2);
		System.out.println(num1+num2);
		
	}

}

package com.onesoft.day4;

public class ToConvertBoolean {
	public static void main(String[] args) {
		
		String s=args[0];
		String s1=args[1];
		boolean b=Boolean.parseBoolean(s);
		boolean b1 = Boolean.parseBoolean(s1);
		System.out.println(b);
		System.out.println(b1);
		
	}

}

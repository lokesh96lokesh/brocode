package com.onesoft.day4;

public class ToConvertFloat {
	public static void main(String[] args) {
		
		String s=args[0];
		String s1=args[1];
		float f = Float.parseFloat(s);
		float f1 = Float.parseFloat(s1);
		System.out.println(f);
		System.out.println(f1);
	}

}

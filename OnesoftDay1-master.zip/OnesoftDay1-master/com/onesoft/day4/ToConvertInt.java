package com.onesoft.day4;

public class ToConvertInt {
	
	public static void main(String[] args) {
		
		String s=args[0];
		int s1=Integer.parseInt(s);
		System.out.println(s1);
		
	}

}

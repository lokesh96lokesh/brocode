package com.onesoft.day4;

public class MultiplyFloatValues{	
	public static void main(String[] args) {
		
		String s=args[0];
		String s1=args[1];
		String s2=args[2];
		float f = Float.parseFloat(s);
		float f1 = Float.parseFloat(s1);
		float f2 = Float.parseFloat(s2);
		
		System.out.println(f+f1+f2);
		
		
	}

}

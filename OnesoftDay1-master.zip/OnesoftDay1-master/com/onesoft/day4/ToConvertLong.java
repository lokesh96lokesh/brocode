
package com.onesoft.day4;

public class ToConvertLong {
	
	public static void main(String[] args) {
		
		String s=args[0];
		String s1=args[1];
		long l=Long.parseLong(s);
		long l1=Long.parseLong(s1);
		System.out.println(l);
		System.out.println(l1);
		
		
	}

}

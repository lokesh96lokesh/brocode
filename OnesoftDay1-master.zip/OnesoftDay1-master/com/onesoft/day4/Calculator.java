package com.onesoft.day4;

public class Calculator {

	public int add(int a, int b) {
		return a + b;

	}

	public int sub()

	{
		int a = 10;
		int b = 2;
		return a - b;

	}

	public void mul(int a, int b) {
		System.out.println(a * b);
	}

	public void div() {
		int a = 10;
		int b = 2;
		System.out.println(a / b);
	}

}

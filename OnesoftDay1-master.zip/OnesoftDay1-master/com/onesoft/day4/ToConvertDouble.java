package com.onesoft.day4;

public class ToConvertDouble {

	public static void main(String[] args) {

		String s = args[0];
		String s1 = args[1];
		double d=Double.parseDouble(s);
		double d1=Double.parseDouble(s1);
		System.out.println(d);
		System.out.println(d1);

	}
}

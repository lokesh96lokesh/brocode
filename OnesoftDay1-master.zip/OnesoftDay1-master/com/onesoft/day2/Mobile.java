package com.onesoft.day2;

public class Mobile {

	String brand;
	String colour;
	boolean isFeatherTouch;
	int ram;
	char chargerType;
	int price;

}

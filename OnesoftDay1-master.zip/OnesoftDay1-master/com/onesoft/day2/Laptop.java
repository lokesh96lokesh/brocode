package com.onesoft.day2;

public class Laptop {
	
	String company;
	int price;
	String processor;
	int ram;
	String hardDisk;
	String color;

}

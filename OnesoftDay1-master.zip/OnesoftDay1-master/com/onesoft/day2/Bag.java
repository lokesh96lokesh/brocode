package com.onesoft.day2;

public class Bag {
	
	String brand;
	int price;
	String color;
	String size;
	int noOfZipsAvailable;
	boolean isLaptopSpaceAvailable;
	

}

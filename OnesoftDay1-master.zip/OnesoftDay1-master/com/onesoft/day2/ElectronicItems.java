package com.onesoft.day2;

public class ElectronicItems {
	
	String name;
	float price;
	float tax;
	float netPrice;
	int taxPercentage;

}

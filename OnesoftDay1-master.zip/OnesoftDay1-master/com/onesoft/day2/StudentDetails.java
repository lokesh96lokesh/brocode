package com.onesoft.day2;

public class StudentDetails {

	String name;
	char gender;
	int rollNo;
	char section;
	int std;
	String place;
	String DOB;
}

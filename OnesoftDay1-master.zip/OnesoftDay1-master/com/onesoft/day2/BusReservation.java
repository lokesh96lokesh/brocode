package com.onesoft.day2;

public class BusReservation {
	
	String name;
	char gender;
	int age;
	String boardingPlace;
	String destinationPlace;
	String date;
	String time;
	String busRegistrationNumber;
	boolean isAcAvailable;
	
}

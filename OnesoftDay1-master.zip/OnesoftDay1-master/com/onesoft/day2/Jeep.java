package com.onesoft.day2;

public class Jeep {
	
	String name;
	String variant;
	String fuelType;
	String color;
	int exShowRoomPrice;
	int tax;
	
}

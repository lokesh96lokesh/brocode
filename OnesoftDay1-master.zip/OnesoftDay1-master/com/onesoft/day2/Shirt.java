package com.onesoft.day2;

public class Shirt {
	
	String brand;
	String size;
	float price;
	float discount;
	float netPrice;

}

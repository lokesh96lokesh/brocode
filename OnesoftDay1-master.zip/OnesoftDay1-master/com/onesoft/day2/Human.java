package com.onesoft.day2;

public class Human {
	
	String name;
	int age;
	char gender;
	float height;
	float weight;
	boolean isPhysicallyChallenged;
	long adhaarNumber;
	String PanNo;
	

}

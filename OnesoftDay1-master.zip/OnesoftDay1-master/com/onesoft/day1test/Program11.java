package com.onesoft.day1test;

public class Program11 {
	public static void main(String[] args) {

		int fatherAge = 40;
		int sonAge = 15;
		int diff = fatherAge - sonAge;
		System.out.println("Differance between father and son : " + diff);

	}

}

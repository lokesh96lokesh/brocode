package com.onesoft.day1test;

public class Program2 {
	
	public static void main(String[] args)
	{
		float a=10.2f;
		float b=5.2f;
		float c=a+b;
		float d=a-b;
		float e=a*b;
		float f=a/b;
		
		System.out.println("Addition of Two Float Number is : " + c);
		System.out.println("Subraction of Two Float Number is : " + d);
		System.out.println("Multiplicaion of Two Float Number is : " +e);
		System.out.println("Division of Two  Float Number is : " +f);
				
	}

}

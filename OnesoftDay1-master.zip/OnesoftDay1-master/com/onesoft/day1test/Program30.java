package com.onesoft.day1test;

public class Program30 {
	
	public static void main(String[] args) {
		int a=20;
		boolean b=a==0;
		System.out.println("Given input is zero: "+b);
	}

}

package com.onesoft.day1test;

public class Program18 {
	public static void main(String[] args) {
		
	int a=10;
	int b=15;
	int c=(a-b)*(a-b);
	System.out.println(c);
	}

}

package com.onesoft.day1test;

public class Program25 {
	public static void main(String[] args) {
		
		String studentName1="Suresh";
		String studentName2="Ruthra";
		int rollNo1=58;
		int rollNo2=45;
		System.out.println("Student Name : " + studentName1 + " - " + "RollNo : " + rollNo1);
		System.out.println("Student Name : " + studentName2 + " - " + "RollNo : " + rollNo2);
		
	}

}

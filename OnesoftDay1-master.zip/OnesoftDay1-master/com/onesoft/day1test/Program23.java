package com.onesoft.day1test;

public class Program23 {
	
	public static void main(String[] args) {
		
		String studentName="Suresh";
		char initial='D';
		System.out.println(studentName+"."+initial);
	}

}

package com.onesoft.day1test;

public class Program12 {

	public static void main(String[] args) {
		
		float weight1=85.2f;
		float weight2=75.5f;
		
		float diff=weight1-weight2;
		System.out.println(diff);
		
		
	}
}

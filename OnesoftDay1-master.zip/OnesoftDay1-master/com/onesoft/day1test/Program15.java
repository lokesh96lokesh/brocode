package com.onesoft.day1test;

public class Program15 {
	public static void main(String[] args) {
		
		float celsius=12;
		float fahrenheit=celsius*(9/5f)+32;
		System.out.println("Fahrenheit : " + fahrenheit);
	}

}

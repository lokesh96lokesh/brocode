package com.onesoft.day1test;

public class Program21 {
	public static void main(String[] args) {
		
		char c='M';
		char d='F';
		char e='T';
		
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
	}

}

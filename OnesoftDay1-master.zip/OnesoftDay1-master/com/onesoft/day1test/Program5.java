package com.onesoft.day1test;

public class Program5 {
	
	public static void main(String[] args) {
		
		int radius=2;
		float pi=3.14f;
		float area=pi*radius*radius;
		System.out.println("Area Of Circle : " + area);
	}

}

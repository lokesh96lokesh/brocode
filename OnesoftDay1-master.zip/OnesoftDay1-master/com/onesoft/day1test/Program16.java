package com.onesoft.day1test;

public class Program16 {
	public static void main(String[] args) {

		double height = 5.100f;
		float weight = 80.9f;
		System.out.println("Height is : " + height);
		System.out.println("Weight is : " + weight);
	}

}

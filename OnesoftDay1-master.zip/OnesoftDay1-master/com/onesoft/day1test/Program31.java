package com.onesoft.day1test;

public class Program31 {
	public static void main(String[] args) {

		String s = "Varun";
		int std = 10;
		char section = 'C';
		System.out.println("Varun Section is: " + section);
	}

}

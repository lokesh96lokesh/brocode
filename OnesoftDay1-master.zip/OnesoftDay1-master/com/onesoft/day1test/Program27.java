package com.onesoft.day1test;

public class Program27 {
	public static void main(String[] args) {
		
		String s="One";
		String s1="soft";
		String s2="Technologies";
		String s3=s+s1+s2;
		System.out.println(s3);
		
	}

}

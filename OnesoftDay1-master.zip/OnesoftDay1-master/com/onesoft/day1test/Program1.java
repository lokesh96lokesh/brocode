package com.onesoft.day1test;

public class Program1 {
	
	public static void main(String[] args) {
		
		int a=20;
		int b=10;
		int c=a+b;
		int d=a-b;
		int e=a*b;
		int f=(a/b);
		System.out.println("Addition of Two Int Number is : " + c);
		System.out.println("Subraction of Two Int Number is : " + d);
		System.out.println("Multiplicaion of Two Int Number is : " +e);
		System.out.println("Division of Two Int Number is : " +f);
		
	}

}

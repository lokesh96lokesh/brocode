package com.onesoft.day1test;

public class Program4 {
	
	public static void main(String[] args) {
		
		long a=8754575818l;
		long b=7845437017l;
		long c=a+b;
		long d=a-b;
		long e=a*b;
		long f=a/b;
		System.out.println("Addition of Two Long Number is : " + c);
		System.out.println("Subraction of Two Long Number is : " + d);
		System.out.println("Multiplicaion of Long Two Number is : " +e);
		System.out.println("Division of Two Long Number is : " +f);
		
	}

}

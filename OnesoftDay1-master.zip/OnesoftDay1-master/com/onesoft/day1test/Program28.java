package com.onesoft.day1test;

public class Program28 {
	 public static void main(String[] args) {
		
		 int a=16;
		 int b=a*a;
		 System.out.println("Square of given number:" + b);
	}

}

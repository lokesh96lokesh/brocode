package com.onesoft.day1test;

public class Program10 {
	
	public static void main(String[] args) {
		
		int sureshAge=30;
		int ruthraAge=25;
		int gopiAge=28;
		int maheshAge=40;
		int veeraAge=30;
		int total=sureshAge+ruthraAge+gopiAge+maheshAge+veeraAge;
		float average=total/5f;
		System.out.println("Average age of Five Student is: " +average);
	}

}

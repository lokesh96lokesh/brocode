package com.onesoft.day1test;

public class Program14 {
	public static void main(String[] args) {

		int a = 10;
		int b = 5;
		int c = 20;
		int d = a * b;
		int e = d + c;
		System.out.println("Result : " + e);
	}

}

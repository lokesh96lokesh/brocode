package com.onesoft.day1test;

public class Program6 {
	
	public static void main(String[] args) {
		
		int a=10;
		int b=15;
		int c=a+b;
		int d=c/2;
		System.out.println("Result is: " + d);
	}

}

package com.onesoft.day1test;

public class Program26 {
	public static void main(String[] args) {
		
		String personName="Suresh";
		float height=5.10f;
		float weight=85.8f;
		double bmi=weight/(height*height);
		
		System.out.println("Name : " + personName + " BMI VALUE : " + bmi);
	}

}

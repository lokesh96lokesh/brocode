package com.onesoft.day1test;

public class Program7 {

	public static void main(String[] args) {

		float a = 123.4f;
		float b = 27.78f;
		double c = a * b;
		System.out.println("Result is : " + c);
	}
}

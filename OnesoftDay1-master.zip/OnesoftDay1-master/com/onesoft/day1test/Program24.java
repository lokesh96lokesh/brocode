package com.onesoft.day1test;

public class Program24 {

	public static void main(String[] args) {
		
	
	String nameOfStudent="Suresh";
	long studentMobileNumber=8754575918l;
	System.out.println("StudentName : " +nameOfStudent + " MobileNumber : " +studentMobileNumber);
	}

}

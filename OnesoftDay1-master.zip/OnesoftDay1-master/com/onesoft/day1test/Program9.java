package com.onesoft.day1test;

public class Program9 {

	public static void main(String[] args) {

		int a = 3;
		int b = 2;
		int c = 4;
		int d = a * a * a;
		int e = b * b * b;
		int f = c * c * c;

		System.out.println("Cube of A value is : " + d);
		System.out.println("Cube of B value is : " + e);
		System.out.println("Cube of f value is : " + f);
	}

}

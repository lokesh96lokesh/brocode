package com.onesoft.day1test;

public class Program29 {
	public static void main(String[] args) {
		
		String myName="Suresh";
		String myFatherName="Devadass";
		System.out.println("Name: " + myName);
		System.out.println("Father Name : "+myFatherName);
	}

}

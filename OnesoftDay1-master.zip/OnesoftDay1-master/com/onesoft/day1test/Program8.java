package com.onesoft.day1test;

public class Program8 {
	
	public static void main(String[] args) {
		
		int sureshAge=30;
		int ruthraAge=15;
		boolean c=sureshAge<18;
		boolean d=ruthraAge<18;
		System.out.println("Suresh is Minor : " + c);
		System.out.println("Ruthra is Minor : " + d);
		
		
	}

}

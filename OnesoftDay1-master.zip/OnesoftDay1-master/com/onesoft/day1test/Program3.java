package com.onesoft.day1test;

public class Program3 {

	public static void main(String[] args) {
		
		double a=2.11111258d;
		double b=1.25487565d;
		double c=a+b;
		double d=a-b;
		double e=a*b;
		double f=a/b;

		System.out.println("Addition of Two Double Number is : " + c);
		System.out.println("Subraction of Two Double Number is : " + d);
		System.out.println("Multiplicaion of Double Two Number is : " +e);
		System.out.println("Division of Two Double Number is : " +f);
		
		
	}

}

package com.onesoft.day1test;

public class Program22 {
	public static void main(String[] args) {

		float a = 5.89f;
		float b = 6.7896f;
		float c = 7.1548f;
		float d = a + b + c;
		System.out.println(d);

	}

}

package com.onesoft.day1test;

public class Program13 {
	public static void main(String[] args) {
		char c='Y';
		char d='N';
		
		System.out.println("Value are : " + c + "," + d);
		
	}

}

package com.onesoft.day1test;

public class Program19 {
	
	public static void main(String[] args) {
		
		String s="Onesoft Technologies";
		String s1="is the good place to";
		String s2="learn Java";
		System.out.println(s);
		System.out.println(s1);
		System.out.println(s2);
		}

}

package com.onesoft.day1test;

public class Program20 {
	public static void main(String[] args) {
		
		String s="One";
		String s1="soft";
		String s2=s+s1;
		System.out.println(s2);
	}

}



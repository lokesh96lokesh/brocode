package com.onesoft.day11;

public class Car extends Vehicle{
	
	boolean isAutomatic;

}

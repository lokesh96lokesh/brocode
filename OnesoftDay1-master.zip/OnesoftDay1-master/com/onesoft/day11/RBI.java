package com.onesoft.day11;

public class RBI {
	
	public int findNetPrice(int amount)
	{
		return amount+amount*6/100;
	}

}

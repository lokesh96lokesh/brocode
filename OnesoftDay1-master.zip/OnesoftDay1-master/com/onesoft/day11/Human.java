package com.onesoft.day11;

public class Human {
	
	String Role;
	String gender;
	int age;
	

}

package com.onesoft.day11;

public class UseAxisBank {
	public static void main(String[] args) {
		
		AxisBank ab=new AxisBank();
				
			System.out.println(ab.findNetPrice(200000));
				
	}
	
}

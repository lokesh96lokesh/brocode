package com.onesoft.day11;

public class UseAction {
	public static void main(String[] args) {
		
		ActionMovie ac=new ActionMovie();
		System.out.println(ac.findSong(5));
		
	}

}

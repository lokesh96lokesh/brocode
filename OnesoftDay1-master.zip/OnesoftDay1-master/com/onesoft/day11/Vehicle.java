package com.onesoft.day11;

public class Vehicle {
	
	String brand;
	int price;
	String color;

}

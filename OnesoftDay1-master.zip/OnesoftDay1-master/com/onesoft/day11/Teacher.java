package com.onesoft.day11;

public class Teacher extends Human{
	
	String qualification;
	int noOfYearsExp;

}

package com.onesoft.day11;

public class UseDoctor extends Doctor {
	
	public static void main(String[] args) {
		
		Doctor d=new Doctor();
		System.out.println(d.Role="Doctor");
		System.out.println(d.qualification="MBBS");
		System.out.println(d.gender="MALE");
		System.out.println(d.age=40);
	}

}

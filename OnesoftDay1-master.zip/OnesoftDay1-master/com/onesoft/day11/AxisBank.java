package com.onesoft.day11;

public class AxisBank extends RBI {
	
	public int findNetPrice(int amount)
	{
		return amount+amount*15/100;
	}

}

package com.onesoft.day11;

public class Bike {
	String brand;
	int price;
	int enginecc;
	public String toString()
	{
		return brand+","+price+","+","+enginecc;
	}

}

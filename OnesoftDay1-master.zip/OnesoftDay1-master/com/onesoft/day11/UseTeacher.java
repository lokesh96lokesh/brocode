package com.onesoft.day11;

public class UseTeacher extends Teacher {
	public static void main(String[] args) {
		
		Teacher t=new Teacher();
		System.out.println(t.Role="Teacher");
		System.out.println(t.qualification="B.ED");
		System.out.println(t.gender="FEMALE");
		System.out.println(t.age=45);
		System.out.println(t.Role="Teaching");
		System.out.println(t.noOfYearsExp=10);
	}

}

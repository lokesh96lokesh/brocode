package com.onesoft.day11;

public class UseSportsCar {
	public static void main(String[] args) {
		
		SportsCar s=new SportsCar();
		s.brand="Mahindra";
		s.color="White";
		s.isAutomatic=false;
		s.price=1500000;
		s.speed=300;
		System.out.println(s.brand+s.color+s.isAutomatic+s.price+s.speed);
		
		
		
	}

}

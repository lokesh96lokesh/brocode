package com.onesoft.day11;

public class UseCat {
	
	public static void main(String[] args) {
		Cat c = new Cat();
		System.out.println(c.type = "PetAnimal");
		System.out.println(c.color="White");
		System.out.println(c.price=2000);
		System.out.println(c.age=1);

		
	}

}

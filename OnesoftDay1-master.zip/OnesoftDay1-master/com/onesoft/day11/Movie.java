package com.onesoft.day11;

public class Movie {
	public String findSong(int noOfSong) {
		if (noOfSong == 5) {
			return "Very Good";
		} else if (noOfSong == 4) {
			return "Good";
		} else if (noOfSong == 3) {
			return "Okay";
		} else {
			return "Average";
		}

	}

	

}

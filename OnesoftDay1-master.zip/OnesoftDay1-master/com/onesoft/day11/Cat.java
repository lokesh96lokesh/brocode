package com.onesoft.day11;

public class Cat extends Animal {
	
	int age;

	
}

package com.onesoft.day11;

public class Animal {
	
	String type;
	String color;
	int price;

}

package com.onesoft.day11;

public class ClimbingBike extends Bike {
	
	float weight;
	
}

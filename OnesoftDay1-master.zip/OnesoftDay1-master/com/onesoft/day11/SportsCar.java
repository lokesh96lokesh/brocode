package com.onesoft.day11;

public class SportsCar extends Car {

	int speed;

}

package com.onesoft.day7;

public class ToCountTheArrayValues {
	public static void main(String[] args) {

		String[] b = { "Suresh", "OneSoft","OMR", "CHENNAI", "PINCODE" };
		int count = 0;

		for (int i = 0; i < b.length; i++) {
			count++;

		}
		System.out.println(count);
	}

}

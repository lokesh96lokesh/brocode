package com.onesoft.day7;

public class ToPrintForward {
	public static void main(String[] args) {
		
		int[] arg=new int[5];
		arg[0]=10;
		arg[1]=20;
		arg[2]=40;
		arg[3]=50;
		arg[4]=60;
		for (int i = 0; i < arg.length; i++) {
			
			System.out.println(arg[i]);
			
		}
		
	}

}

package com.onesoft.day9;

public class FunctionsSub {

	int num1;
	int num2;

	public int sub() {

		int total = num1 - num2;
		return total;

	}

	public int sub1(int num1, int num2) {

		int total = num1 - num2;
		return total;
	}

	public void sub2() {
		int total = num1 - num2;
		System.out.println(total);
	}

	public void sub3(int num1, int num2) {
		int total = num1 - num2;
		System.out.println(total);

	}

}

package com.onesoft.day9;

public class Cat {
	
	String breedName;
	int age;
	boolean isSmall;
	String color;
	
	public Cat(String breedName,String color)
	{
		this.breedName=breedName;
		this.color=color;
		
	}

}

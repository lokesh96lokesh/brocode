package com.onesoft.day9;

public class Division {
	
	int a;
	int b;
	
	public int div()
	{
		
		int total=a/b;
		return total;
		
	}
	public int div1(int a,int b)
	{
		int total=a/b;
		return total;
	}
	public void div2() {
	
		System.out.println(a/b);
		
	}
	public void div3(int a,int b) {
		
		int total=a/b;
		
		System.out.println(total);
		
	}

}

package com.onesoft.day9;

public class Addition {
	
	int num1;
	int num2;

	public int add() {

		int total = num1 + num2;
		return total;

	}

	public int add1(int num1, int num2) {

		int total = num1 + num2;
		return total;
	}

	public void add2() {
		int total = num1 + num2;
		System.out.println(total);
	}

	public void add3(int num1, int num2) {
		int total = num1 + num2;
		System.out.println(total);

	}


}

package com.onesoft.day9;

public class Multiplication {
	
	int a;
	int b;
	
	public int mul()
	{
		
		int total=a*b;
		return total;
		
	}
	public int mul1(int a,int b)
	{
		int total=a*b;
		return total;
	}
	public void mul2() {
	
		System.out.println(a*b);
		
	}
	public void mul3(int a,int b) {
		
		int total=a*b;
		
		System.out.println(total);
		
	}


}

package com.onesoft.day9;

public class UseFactorial {
	
	public static void main(String[] args) {
		
		Factorial f=new Factorial();
		System.out.println(f.fact(5));
		
	}

}

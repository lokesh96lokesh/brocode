package com.onesoft.day9;

public class UseFunctionsSub {
	public static void main(String[] args) {
		

	
	FunctionsSub f=new FunctionsSub();
	
	f.num1=20;
	f.num2=10;
	
	System.out.println(f.sub());
	System.out.println(f.sub1(80,30));
	f.sub2();
	f.sub3(100, 20);
	
	
	
	
	}
}

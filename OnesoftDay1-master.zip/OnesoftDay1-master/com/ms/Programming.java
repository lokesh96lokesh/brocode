package com.ms;

public abstract class Programming {
	
	public abstract void show();
	public abstract void display();	

}

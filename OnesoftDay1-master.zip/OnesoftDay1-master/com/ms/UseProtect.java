package com.ms;

public class UseProtect  {
	
	protected void name() {
		System.out.println("I M protected");
	}
	public void haro() {
		System.out.println("i am public useh");
	}

}

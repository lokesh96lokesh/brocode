package com.ms;

public class InterClass implements Inter1{

	@Override
	public void disp() {
		// TODO Auto-generated method stub
		
	}

	

}

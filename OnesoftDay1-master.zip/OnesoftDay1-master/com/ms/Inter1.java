package com.ms;

public interface Inter1 {
	
	void disp();

}

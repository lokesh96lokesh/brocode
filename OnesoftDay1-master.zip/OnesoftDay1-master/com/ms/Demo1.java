package com.ms;

public class Demo1 {

	Demo2 d2 = new Demo2();

	public String test1() {
		String name = "Suresh";
		return d2.test2(name);
	}
	
	

}

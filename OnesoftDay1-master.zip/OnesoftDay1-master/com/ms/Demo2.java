package com.ms;

public class Demo2 {

	public String test2(String n) {

		return n;
	}
public static void main(String[] args) {
	
	UseProtect u =new UseProtect();
	u.haro();
	u.name();
}

}

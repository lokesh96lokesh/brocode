import com.ms.UseProtect;

public class Protect  {
	
//	@Override
//	protected void name() {
//	
//		super.name();
//	}
	protected void dis() {
		System.out.println("I m child Class Protect");

	}
	
	public static void main(String[] args) {
		
	UseProtect u= new UseProtect();
	u.haro();
	}
	
	
}

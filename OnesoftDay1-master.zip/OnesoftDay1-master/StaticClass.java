//
//public class StaticClass {
//    static int a=20;
//	public static void main(String[] args) {
//		//StaticClass sc= new StaticClass();
//		System.out.println(a);
//	}
//
//}
class StaticClass{  
  public static void main(String[] args) {
	System.out.println("hello");
	
}
  static{  
	  int a=10;
	 System.out.println(a);
	 }  
	 
}  
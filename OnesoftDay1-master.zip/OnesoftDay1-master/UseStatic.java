
public class UseStatic {

	public static void main(String[] args) {
		
	StaticDifferance.a=25;
	System.out.println(StaticDifferance.a=25);
	}
	
}

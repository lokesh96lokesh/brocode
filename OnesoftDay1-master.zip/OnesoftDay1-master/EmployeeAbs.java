
public abstract class EmployeeAbs implements inter {

}

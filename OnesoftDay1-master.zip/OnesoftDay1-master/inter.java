import com.onesoft.day13collection.Age;

public interface inter {
	void eat();
	void age();

}

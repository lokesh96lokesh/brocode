
public class StringBuffer1 {
	public static void main(String[] args) {
		
		StringBuilder s=new StringBuilder("Suresh");
		System.out.println(s.hashCode());
		s.append("Devadass");
		System.out.println(s.hashCode());
		
		System.out.println("---------------------");
		
		StringBuffer ss=new StringBuffer();

	}
}

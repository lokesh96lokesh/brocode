package java8;

public class Nums {

	public static void main(String[] args) {
		
		
		Addition add=(a,b)->(a+b);
		System.out.println(add.num(10, 76));
		
		Addition sub=(a,b)->(a-b);
		System.out.println(sub.num(10, 45));
		
		
		
	}
	
	
	
}

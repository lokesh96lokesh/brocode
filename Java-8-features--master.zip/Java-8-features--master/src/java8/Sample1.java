package java8;

public class Sample1 implements Sample {

	public void gender(String g) {
		System.out.println(g);

	}
	
	public static String name() {
		return "Venkates";
	}

	public  int age(int years) {
		return years-24;

	}


}

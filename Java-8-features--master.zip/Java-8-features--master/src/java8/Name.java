package java8;

@FunctionalInterface
public interface Name {

	public void stuInfo();

}

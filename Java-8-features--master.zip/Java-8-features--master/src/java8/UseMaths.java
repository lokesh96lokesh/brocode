package java8;

public class UseMaths {

	public static void main(String[] args) {
		
		int m1=60;
		int m2=70;
		int m3=50;
		int m4=90;
		int m5=90;
		
	int [] a= {m1,m2,m3,m4,m5};
		
		
		Maths c1=new Maths();
		System.out.println(c1.findAvg(a));
		System.out.println(c1.findMax(a));
		System.out.println(c1.findMin(a));
		
		
		
 
	}

}

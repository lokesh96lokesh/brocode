package java8;

public class UseMemory {

	
	public static void main(String[] args) {
		
		

		Memory m1=new Memory();
		Memory m2=new Memory();
		Memory m3=new Memory();
		
		
	}
}

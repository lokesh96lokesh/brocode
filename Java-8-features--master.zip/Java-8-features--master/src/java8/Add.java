package java8;

@FunctionalInterface
public interface Add {

	public void mat(int a, int b);

}

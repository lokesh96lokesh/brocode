package java8;

public class Task1 {

	
	
}

package java8;

public class UseAdd {
public static void main(String[] args) {
	
	Add add=(a,b)->System.out.println(a+b);
	
	add.mat(20, 20);
	
	
	
	
}	
	
	
}

package java8;

@FunctionalInterface
public interface Addition {

	public int num(int a, int b);

}

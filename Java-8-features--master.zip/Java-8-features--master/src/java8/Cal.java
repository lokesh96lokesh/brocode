package java8;

@FunctionalInterface
public interface Cal {
	public int math(int a, int b);

}

package java8;

public class UseName {

	public static void main(String[] args) {
		
		
	Name name=()->System.out.println("Hari");
	name.stuInfo();
	
	Name gender=()->System.out.println("Male");
	gender.stuInfo();
	
	Name loc=()->System.out.println("Salem");
	loc.stuInfo();
	
		
	}
	
}

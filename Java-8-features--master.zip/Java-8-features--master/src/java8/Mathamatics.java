package java8;

@FunctionalInterface

public interface Mathamatics {

	public int maths(int[] a);
}

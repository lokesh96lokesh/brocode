package com.onesoft.emp.customexception;

public class AgeNotFoundException extends Exception {

	public AgeNotFoundException(String msg) {
		super(msg);
	}
}

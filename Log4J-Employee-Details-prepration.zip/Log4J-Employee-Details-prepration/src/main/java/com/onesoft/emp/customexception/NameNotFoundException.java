package com.onesoft.emp.customexception;

public class NameNotFoundException extends Exception {

	public NameNotFoundException(String m) {
		super(m);
	}

}

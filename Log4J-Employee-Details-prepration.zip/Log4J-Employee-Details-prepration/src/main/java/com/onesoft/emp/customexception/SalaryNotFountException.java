package com.onesoft.emp.customexception;

public class SalaryNotFountException extends Exception {

	public SalaryNotFountException(String j) {
		super(j);
	}

}

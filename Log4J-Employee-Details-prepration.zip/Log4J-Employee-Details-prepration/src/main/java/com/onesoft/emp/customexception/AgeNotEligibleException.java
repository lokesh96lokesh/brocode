package com.onesoft.emp.customexception;

public class AgeNotEligibleException extends Exception {

	public AgeNotEligibleException(String msg) {
		super(msg);
	}

}

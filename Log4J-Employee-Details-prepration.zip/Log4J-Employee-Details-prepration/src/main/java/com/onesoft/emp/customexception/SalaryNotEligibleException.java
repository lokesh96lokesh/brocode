package com.onesoft.emp.customexception;

public class SalaryNotEligibleException  extends Exception{
	
	public SalaryNotEligibleException(String msg) {
		super(msg);
	}

}

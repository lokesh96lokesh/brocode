package ForLoop;

public class Main {
    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
            System.out.println("Current counter is: " + i);
        }
        for (int i = 10; i >= 0; i--) {
            System.out.println("Current reverse counter is: " + i);
        }
        System.out.println("Happy new year!");
    }
}

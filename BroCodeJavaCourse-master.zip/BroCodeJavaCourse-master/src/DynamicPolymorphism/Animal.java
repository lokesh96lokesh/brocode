package DynamicPolymorphism;

public class Animal {
    public void speak() {
        System.out.println("Animal goes *burrr");
    }
}

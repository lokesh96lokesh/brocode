package Interfaces;

public interface Predator {
    void hunt();
}

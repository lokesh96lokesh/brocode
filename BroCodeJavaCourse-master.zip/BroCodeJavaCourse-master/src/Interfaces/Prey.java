package Interfaces;

public interface Prey {
    void flee();
}

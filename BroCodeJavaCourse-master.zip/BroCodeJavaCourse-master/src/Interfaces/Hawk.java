package Interfaces;

public class Hawk implements Predator {
    @Override
    public void hunt() {
        System.out.println("Hawk is hunting");
    }
}

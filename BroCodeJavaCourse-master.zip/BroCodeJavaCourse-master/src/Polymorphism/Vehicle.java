package Polymorphism;

public class Vehicle {
    public void go() {

    }
}

package Polymorphism;

public class Car extends Vehicle {

    @Override
    public void go() {
        System.out.println("*The car begin moving*");
    }
}

package Polymorphism;

public class Boat extends Vehicle {

    @Override
    public void go() {
        System.out.println("*The boat begin moving*");
    }
}

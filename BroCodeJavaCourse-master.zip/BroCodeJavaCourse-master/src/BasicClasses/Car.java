package BasicClasses;

public class Car {
    String make = "Chevrolet";
    String model = "Corvette";
    int year = 2022;
    String color = "red";
    double price = 50000.00;

    void drive() {
        System.out.println("You drive the car");
    }

    void brake() {
        System.out.println("You step on the brake");
    }
}

package ForEach;

public class Main {
    public static void main(String[] args) {
        String[] animals = {"Cat", "Dog", "Rat", "Peacock"};
        for (String animal: animals) {
            System.out.println("Animal: " + animal);
        }
    }
}

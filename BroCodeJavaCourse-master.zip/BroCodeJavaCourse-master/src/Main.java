public class Main {
    public static void main(String[] args) {
        System.out.println("I love Pizza");
        System.out.println("It's really good!");
        // This is a comment
        /*
         * This is a
         * multi line comment
         *
         */
        int x; // declaration
        x = 10; // assignment
        System.out.println(x);
        int y = 100; // initialization
        System.out.println("My number is: " + y);
        long z = 109890843485908L;
        byte b = 100;
        boolean isTrue = true;
        float f = 13939.989f;
        double d = 8908.39080;
        char c = 'f';
        String name = "BoringByte";
        System.out.println("Hello " + name);
    }
}

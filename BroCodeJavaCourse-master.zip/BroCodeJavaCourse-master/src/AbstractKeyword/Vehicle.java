package AbstractKeyword;

public abstract class Vehicle {
    abstract void go();
}

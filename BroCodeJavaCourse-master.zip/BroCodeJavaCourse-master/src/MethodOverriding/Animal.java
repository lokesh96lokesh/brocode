package MethodOverriding;

public class Animal {
    void speak() {
        System.out.println("The animal speaks");
    }
}

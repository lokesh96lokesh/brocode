package Expressions;

public class Main {
    public static void main(String[] args) {
        int friends = 10;
        friends += 1;
        System.out.println(friends);
        double friend = (double) friends / 3;
        System.out.println(friend);
    }
}

package inheritance;

public class Bicycle extends Vehicle {
    int wheels = 2;
    int pedals = 2;
}

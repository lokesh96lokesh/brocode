package ToStringMethod;

public class Main {
    public static void main(String[] args) {
        Car car = new Car();
        System.out.println(car);
        System.out.println(car.toString());
    }
}

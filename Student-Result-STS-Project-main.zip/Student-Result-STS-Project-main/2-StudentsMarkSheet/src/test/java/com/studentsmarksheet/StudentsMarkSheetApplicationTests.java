package com.studentsmarksheet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentsMarkSheetApplicationTests {

	@Test
	void contextLoads() {
	}

}

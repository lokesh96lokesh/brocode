package com.students.customexception;

public class NameNotFoundException extends Exception {

	public NameNotFoundException(String a) {
		super(a);
	}

}

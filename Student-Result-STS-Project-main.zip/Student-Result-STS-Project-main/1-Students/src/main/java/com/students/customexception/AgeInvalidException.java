package com.students.customexception;

public class AgeInvalidException extends Exception  {
	
	public AgeInvalidException(String e) {
		super(e);
	}

}

package com.thegreatapi.ahundreddaysofjava.day072.animal;

public interface Animal {

    String speak();
}

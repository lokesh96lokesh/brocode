package com.thegreatapi.ahundreddaysofjava.day073.paymentprocessor;

public interface PaymentProcessor {

    void process(Payment payment);
}
package com.thegreatapi.ahundreddaysofjava.day075;

public interface PaymentProcessor {

    void process(Payment payment);
}

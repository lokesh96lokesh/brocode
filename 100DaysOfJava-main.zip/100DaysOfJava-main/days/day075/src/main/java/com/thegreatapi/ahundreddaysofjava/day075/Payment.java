package com.thegreatapi.ahundreddaysofjava.day075;

public record Payment() {
}
package com.thegreatapi.ahundreddaysofjava.day075;

class DependencyA {

    void process() {
        System.out.println("Dependency A is processing...");
    }
}
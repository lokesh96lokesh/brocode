package com.thegreatapi.ahundreddaysofjava.day075;

public class DependencyB {

    void process() {
        System.out.println("Dependency B is processing...");
    }
}
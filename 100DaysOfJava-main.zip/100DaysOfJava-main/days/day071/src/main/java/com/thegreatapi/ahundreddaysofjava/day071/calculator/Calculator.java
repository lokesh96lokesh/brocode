package com.thegreatapi.ahundreddaysofjava.day071.calculator;

public interface Calculator {

    int sum(int a, int b);
}

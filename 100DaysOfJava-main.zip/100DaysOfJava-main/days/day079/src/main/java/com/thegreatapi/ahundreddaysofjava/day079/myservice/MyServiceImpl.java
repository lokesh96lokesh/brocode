package com.thegreatapi.ahundreddaysofjava.day079.myservice;

class MyServiceImpl implements MyService {

    @Override
    public void run() {
        System.out.println("Running my service...");
    }
}
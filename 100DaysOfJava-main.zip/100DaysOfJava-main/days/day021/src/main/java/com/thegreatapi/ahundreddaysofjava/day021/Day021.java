package com.thegreatapi.ahundreddaysofjava.day021;

public class Day021 {

}
package forloop;

public class FindCount {
	public static void main(String args []) {
		int total=0;
		for(int i=0;i<=5;i++) {
			total=total+1;
		}
		System.out.println(total);
	}

}

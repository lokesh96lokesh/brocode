package forloop;

public class Namebackward {
	public static void main(String args []) {
		String a="Siva";
		for(int i=a.length();i>=0;i--)
		{
			System.out.println(a.charAt(i));
		}
	}

}

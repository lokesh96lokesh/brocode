package forloop;

public class Forward {
	public static void main(String args []) {
		String a="Siva";
		for(int i=0;i<=5;i++)
		{
			System.out.println(a);
			
		}
	}

}

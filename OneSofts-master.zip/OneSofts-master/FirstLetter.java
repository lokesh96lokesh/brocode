package forloop;

public class FirstLetter {
	public static void main(String args[]) {
		String[] words= {"siva,bharani,gokul"};
		for(int i=0;i<words.length;i++) {
			System.out.println(words[i].charAt(0));
		}
	}
	

}

package forloop;

public class Continue {
	public static void main(String args [] ) {
		for(int i=1;i<=100;i++) {
			if(i%5==0) {
				continue;
			}
			else {
				System.out.println(i);
			}
		}
	}

}

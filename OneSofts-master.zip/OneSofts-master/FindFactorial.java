package forloop;

public class FindFactorial {
	public static void main(String args []) {
		int total=1;
		for(int i=1;i<=5;i++) {
			total=total*i;
		}
		System.out.println(total);
	}
	

}

package forloop;

public class Backward {
	public static void main(String args []) {
		
		for(int i=5;i>=0;i--)
		{
			System.out.println(i);
			
		}
	}
}

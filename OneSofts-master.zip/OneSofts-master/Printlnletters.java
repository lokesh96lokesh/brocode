package forloop;

public class Printlnletters {
	public static void main(String args []) {
		String word="bubble";
		for(int i=0;i<word.length();i++) {
			if(word.charAt(i)=='b')
			{
				System.out.println("i");
			}
		}
	}

}


package forloop;

public class EvenOddprogram {
	public static void main(String args []) {
		for(int i=85;i<=100;i++) {
			if(i%2==0) {
				System.out.println(+i+" is even num");
				
			}
			else
			{
				System.out.println(i+" is odd number");
			}
		}
	}

}

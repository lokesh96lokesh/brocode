package forloop;

public class Findtotal {
	public static void main(String args [] ) {
		int total=0;
		for(int i=0;i<=10;i++) {
			total=total+i;
			
		}
		System.out.println(total);
	}

}

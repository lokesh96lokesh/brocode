package forloop;

public class PrintNumber {
	public static void main(String args [] ) {
		int[] nums= {7,8,9,10,12,13};
		for(int i=nums.length-1;i>0;i--)
		{
			System.out.println(nums[i]);
		}
	}

}

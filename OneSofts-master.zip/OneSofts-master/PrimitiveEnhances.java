package forloop;

public class PrimitiveEnhances {
	public static void main(String args []) {
		int[] a= {2,5,5,85,85,54};
		for(Integer x:a) {
			System.out.println(x);
		}
	}

}

package revision;

public class FindTheLeafYear {
public static void main(String[] args) {
	
	int a=2022;
	
	if(a%4==0&&a%100!=0) {
		System.out.println(a+" This is a leaf Year");
	}
	else {
		System.out.println(a+" This is Not a Leaf Year");
	}
	
	
	
}
	
	
}

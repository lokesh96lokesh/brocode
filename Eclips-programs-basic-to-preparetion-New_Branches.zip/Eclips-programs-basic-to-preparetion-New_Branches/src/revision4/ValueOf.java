 package revision4;

public class ValueOf {

	public static void main(String[] args) {

		int a = 10;
		String d = "67";
		int c = Integer.valueOf(d);
		String b = String.valueOf(a);
		System.out.println(c + 14 + b);

	}

}

package revisionJava8;

public class PrintLast {
	public static void main(String[] args) {
		
	}
}

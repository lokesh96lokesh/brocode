package revisionJava8;

@FunctionalInterface
public interface FindVowel {

	public void findv(String a[]);

}

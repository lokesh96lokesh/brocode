package revisionJava8;

public class UseMethodRefrance {
	public static void main(String[] args) {
		
		
		
		
		
		
		
	}
	
	
	
}

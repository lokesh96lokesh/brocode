package revisionJava8;

@FunctionalInterface
public interface MethodRef {

	void getFind(String[] a);
}

package revisionJava8;

@FunctionalInterface
public interface FindEven {

	public void even(int a[]);

}

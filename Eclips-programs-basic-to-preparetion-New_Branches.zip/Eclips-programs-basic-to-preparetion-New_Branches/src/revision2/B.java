package revision2;

public interface B {

}

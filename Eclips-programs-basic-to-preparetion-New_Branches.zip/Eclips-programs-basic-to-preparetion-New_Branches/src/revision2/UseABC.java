package revision2;

public class UseABC {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

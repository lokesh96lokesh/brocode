package revision2;

public interface A {

	int a = 0;

	void add();

}

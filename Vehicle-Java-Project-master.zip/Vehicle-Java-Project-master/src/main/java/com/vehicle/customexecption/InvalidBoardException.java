package com.vehicle.customexecption;

public class InvalidBoardException  extends Exception{
	
	public InvalidBoardException(String msg) {
		super(msg);
	}
	
}

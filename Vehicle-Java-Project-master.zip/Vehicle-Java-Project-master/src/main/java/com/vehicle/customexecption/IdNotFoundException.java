package com.vehicle.customexecption;

public class IdNotFoundException extends Exception {
	
	public IdNotFoundException(String a) {
	super(a);
	
	}

	
}

package com.vehicle.customexecption;

public class BrandNotFoundException extends Exception {

	public BrandNotFoundException(String e) {
		super(e);
	}

}
